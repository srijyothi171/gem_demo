# Uses the Python Imaging Library
# `pip install Pillow` works too
from PIL import Image
import boto3
import json
import urllib.parse
import piexif
import os
import uuid

print('Loading function')

s3 = boto3.client('s3')


def lambda_handler(event, context):
    print("Lambda Function to remove metadata from source bucket file and copy it into target bucket ")

    # Get the Source bucket name and filename
    s_bucket = event['Records'][0]['s3']['bucket']['name']
    s_obj = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')

    
    # print the Source & target bucket name and filename
    t_bucket = 'tests3exifb'
    print("source Bucket name: " + s_bucket)
    print("Source File name: " + s_obj)
    print("Target Bucket name: " + t_bucket)

    copy_source = {'Bucket': s_bucket, 'Key': s_obj}

    try:
       
        # print Metadata using head_object
        response = s3.head_object(Bucket=s_bucket, Key=s_obj)
        print ("CONTENT TYPE : "+str(response['ContentType']))
        print ('ETag :' +str(response['ETag']))
        print ('Content-Length :'+str(response['ContentLength']))
        
        # Remove EXIF data by using PIL import Image; if PIL not working on your env add dependencies to this code
        image = Image.open(s_obj)
        image.save(s_obj)

        #t_obj = image_without_exif.save(u"clean_{}".format(image_filename))

        # Copying file into target bucket
        s3.copy_object(Bucket = t_bucket, Key = s_obj, CopySource = copy_source)
        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
